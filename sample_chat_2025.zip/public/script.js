function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content').forEach(section => {
        section.style.display = 'none';
    });
    
    // Remove active class from all nav links
    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId + '-content').style.display = 'block';
    
    // Add active class to clicked nav link
    document.querySelector(`a[onclick="showSection('${sectionId}')"]`).classList.add('active');
}

function addMessage(message, type) {
    const messagesDiv = document.getElementById('chat-messages');
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', type);
    messageElement.textContent = message;
    messagesDiv.appendChild(messageElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

async function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (message === '') return;
    
    // Clear input
    input.value = '';
    
    // Add user message
    addMessage(message, 'user');
    
    try {
        // Send message to server
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: message })
        });
        
        const data = await response.json();
        
        // Add AI response
        addMessage(data.message, 'assistant');
    } catch (error) {
        console.error('Error:', error);
        addMessage('죄송합니다. 오류가 발생했습니다.', 'system');
    }
}

// Handle enter key in textarea
document.getElementById('chat-input').addEventListener('keypress', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});

// File upload handling
document.getElementById('upload-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData();
    const fileInput = document.getElementById('file-input');
    const resultDiv = document.getElementById('upload-result');
    
    if (fileInput.files.length === 0) {
        resultDiv.className = 'upload-result error';
        resultDiv.textContent = '파일을 선택해주세요.';
        return;
    }
    
    formData.append('file', fileInput.files[0]);
    
    try {
        const response = await fetch('/api/upload', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (response.ok) {
            resultDiv.className = 'upload-result success';
            resultDiv.textContent = data.message;
            fileInput.value = '';
            updateFileList(data.filename);
        } else {
            resultDiv.className = 'upload-result error';
            resultDiv.textContent = data.error;
        }
    } catch (error) {
        console.error('Error:', error);
        resultDiv.className = 'upload-result error';
        resultDiv.textContent = '파일 업로드 중 오류가 발생했습니다.';
    }
});

// Analysis form handling
document.getElementById('analysis-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const resultDiv = document.getElementById('analysis-result');
    
    const formData = {
        feature1: parseFloat(document.getElementById('feature1').value),
        feature2: parseFloat(document.getElementById('feature2').value),
        feature3: parseFloat(document.getElementById('feature3').value)
    };
    
    try {
        const response = await fetch('/api/analyze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            resultDiv.innerHTML = `
                <h3>분석 결과</h3>
                <p>${data.prediction}</p>
                <pre>${JSON.stringify(data.features, null, 2)}</pre>
            `;
        } else {
            resultDiv.innerHTML = `<p class="error">${data.error}</p>`;
        }
    } catch (error) {
        console.error('Error:', error);
        resultDiv.innerHTML = '<p class="error">분석 중 오류가 발생했습니다.</p>';
    }
});

// 파일 목록 업데이트 함수 정의
function updateFileList(filename) {
    const fileListContainer = document.getElementById('uploadedFiles');
    if (!fileListContainer) {
        console.error('File list container not found');
        return;
    }

    const fileItem = document.createElement('div');
    fileItem.className = 'file-item';
    fileItem.innerHTML = `<span>${filename}</span>`;
    fileListContainer.appendChild(fileItem);
}

// 페이지 로드 완료 후 실행
window.addEventListener('load', () => {
    // 파일 업로드 폼 처리
    const uploadForm = document.getElementById('uploadForm');
    if (uploadForm) {
        uploadForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            try {
                const formData = new FormData(uploadForm);
                const response = await fetch('/api/upload', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();
                
                if (response.ok) {
                    updateFileList(data.filename);
                    alert(data.message);
                    uploadForm.reset();
                } else {
                    throw new Error(data.error || '파일 업로드 중 오류가 발생했습니다.');
                }
            } catch (error) {
                console.error('Error:', error);
                alert(error.message);
            }
        });
    }

    // 분석 폼 처리
    const analysisForm = document.getElementById('analysisForm');
    if (analysisForm) {
        analysisForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            try {
                const formData = new FormData(e.target);
                const analysisData = {
                    inHclus: Number(formData.get('inHclus')),
                    inPropercent: Number(formData.get('inPropercent')),
                    inPromotion: Number(formData.get('inPromotion')),
                    inHoliday: Number(formData.get('inHoliday'))
                };

                const response = await fetch('/api/analyze', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(analysisData)
                });

                const data = await response.json();
                
                if (response.ok) {
                    // 결과 표시
                    const resultComponent = document.getElementById('resultComponent');
                    const predictionValue = document.getElementById('predictionValue');
                    
                    predictionValue.textContent = `예측값: ${data.prediction}`;
                    resultComponent.style.display = 'block';
                } else {
                    throw new Error(data.error || '분석 중 오류가 발생했습니다.');
                }
            } catch (error) {
                console.error('Error:', error);
                alert(error.message);
            }
        });
    }
}); 