const express = require('express');
const path = require('path');
const axios = require('axios');
const multer = require('multer');
const fs = require('fs');

const app = express();
const port = 3000;

// 파일 업로드를 위한 설정
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        // 원본 파일명 그대로 사용
        const originalname = Buffer.from(file.originalname, 'latin1').toString('utf8');
        // 동일한 파일명이 존재하는 경우 처리
        let filename = originalname;
        let counter = 1;
        while (fs.existsSync(path.join(uploadDir, filename))) {
            const ext = path.extname(originalname);
            const name = path.basename(originalname, ext);
            filename = `${name} (${counter})${ext}`;
            counter++;
        }
        cb(null, filename);
    }
});

const upload = multer({ 
    storage: storage,
    fileFilter: function (req, file, cb) {
        cb(null, true);
    }
});

// Middleware for parsing JSON bodies
app.use(express.json());
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

// API endpoint for chat
app.post('/api/chat', async (req, res) => {
    try {
        // Using ngrok URL instead of IP address
        const response = await axios.post('https://7334-112-76-111-22.ngrok-free.app/predict', {
            question: req.body.message
        });
        res.json({ message: response.data.prediction });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// 파일 업로드 엔드포인트
app.post('/api/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: '파일이 업로드되지 않았습니다.' });
    }
    res.json({ 
        message: '파일이 성공적으로 업로드되었습니다.',
        filename: req.file.filename
    });
});

// 분석 엔드포인트
app.post('/api/analyze', async (req, res) => {
    try {
        const { inHclus, inPropercent, inPromotion, inHoliday } = req.body;
        
        // 외부 분석 서버에 요청
        const response = await axios.post('https://e609-35-245-147-79.ngrok-free.app/predictBase', {
            inHclus: Number(inHclus),
            inPropercent: Number(inPropercent),
            inPromotion: Number(inPromotion),
            inHoliday: Number(inHoliday)
        });

        // API 응답 형식에 맞춰 prediction 값만 전달
        res.json({ 
            prediction: response.data.prediction
        });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: '분석 중 오류가 발생했습니다.' });
    }
});

// Serve the main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
}); 